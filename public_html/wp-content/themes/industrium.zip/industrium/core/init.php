<?php
/*
 * Created by Artureanec
*/

require_once(get_template_directory() . "/core/customizer/customizer.php");
require_once(get_template_directory() . "/core/classes.php");
require_once(get_template_directory() . "/core/metabox.php");
require_once(get_template_directory() . "/core/tgm/init.php");
require_once(get_template_directory() . "/core/fonts.php");
require_once(get_template_directory() . "/core/ajax.php");
require_once(get_template_directory() . "/core/import/import.php");
